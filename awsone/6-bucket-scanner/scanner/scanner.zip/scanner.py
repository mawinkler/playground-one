import inspect
import json
import logging
import os
import time
import urllib.parse
from datetime import datetime
from time import sleep

import amaas.grpc
import boto3
import requests

_LOGGER = logging.getLogger()
_LOGGER.setLevel("INFO")


s3 = boto3.resource("s3")
s3_client = boto3.client("s3")


V1_REGION = os.getenv("V1_REGION")
V1_API_KEY = os.getenv("V1_API_KEY")
if V1_REGION == "us-east-1" or V1_REGION == "":
    API_BASE_URL = "https://api.xdr.trendmicro.com"
else:
    API_BASE_URL = f"https://api.{V1_REGION}.xdr.trendmicro.com"

# FSS
V1_FSS = os.getenv("V1_FSS", False)
if V1_FSS == "true":
    V1_FSS = True
else:
    V1_FSS = False
FSS_TAG_PREFIX = "filesecurity-"
FSS_PML = True
FSS_FEEDBACK = True
FSS_VERBOSE = True
FSS_DIGEST = True
# /FSS

# SANDBOX
V1_SANDBOX = os.getenv("V1_SANDBOX", False)
if V1_SANDBOX == "true":
    V1_SANDBOX = True
else:
    V1_SANDBOX = False
SB_TAG_PREFIX = "sandbox-"
URL_PATH_ANALYZE = "/v3.0/sandbox/files/analyze"
URL_PATH_TASKS = "/v3.0/sandbox/tasks"
HEADERS = {"Authorization": "Bearer " + V1_API_KEY}
QUERY_PARAMS = {}
# /SANDBOX


# #############################################################################
# File Security Handling
# #############################################################################
def fss_submit(handle, key, buffer):
    try:
        scan_resp = amaas.grpc.scan_buffer(
            handle,
            buffer,
            key,
            tags=["pgo"],
            pml=FSS_PML,
            feedback=FSS_FEEDBACK,
            verbose=FSS_VERBOSE,
            digest=FSS_DIGEST,
        )
    except Exception as e:
        _LOGGER.error(e, extra={"function": inspect.currentframe().f_code.co_name})
        _LOGGER.error(
            "Error scanning object {}.".format(key), extra={"function": inspect.currentframe().f_code.co_name}
        )

    response = json.loads(scan_resp)

    scanning_result = response.get("result")
    findings = scanning_result.get("atse").get("malwareCount")
    scan_result = "malicious" if findings else "no issues found"
    scan_date = datetime.strftime(datetime.fromisoformat(response.get("timestamp").get("end")), "%m/%d/%Y %H:%M:%S")
    malware_name = scanning_result.get("atse").get("malware")[0].get("name") if findings else "n/a"

    tags = [
        f"{FSS_TAG_PREFIX}scanned=true",
        f"{FSS_TAG_PREFIX}scan-date={scan_date}",
        f"{FSS_TAG_PREFIX}scan-result={scan_result}",
        f"{FSS_TAG_PREFIX}scan-detail-code={malware_name}",
    ]

    return tags


# #############################################################################
# Sandbox Handling
# #############################################################################
def sandbox_submit(key, buffer):

    data = {
        #    'documentPassword': 'YOUR_DOCUMENTPASSWORD (base64-encoded characters)',
        #    'archivePassword': 'YOUR_ARCHIVEPASSWORD (base64-encoded characters)',
        #    'arguments': 'YOUR_ARGUMENTS (base64-encoded characters)'
    }
    files = {"file": (key, buffer, "application/octet-stream")}
    try:
        response = requests.post(
            API_BASE_URL + URL_PATH_ANALYZE, params=QUERY_PARAMS, headers=HEADERS, data=data, files=files
        )
        response.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        _LOGGER.error(errh.args[0], extra={"function": inspect.currentframe().f_code.co_name})
        raise
    except requests.exceptions.ReadTimeout:
        _LOGGER.error("Time out", extra={"function": inspect.currentframe().f_code.co_name})
        raise
    except requests.exceptions.ConnectionError:
        _LOGGER.error("Connection error", extra={"function": inspect.currentframe().f_code.co_name})
        raise
    except requests.exceptions.RequestException:
        _LOGGER.error("Exception request", extra={"function": inspect.currentframe().f_code.co_name})
        raise

    task_id = response.json().get("id")

    _LOGGER.info(f"Sandbox Task ID: {task_id}", extra={"function": inspect.currentframe().f_code.co_name})

    return task_id


def sandbox_wait_for_result(task_id):

    sandbox_analysis_results = None
    sandbox_analysis_failed = False
    while sandbox_analysis_results is None and not sandbox_analysis_failed:
        try:
            response = requests.get(API_BASE_URL + URL_PATH_TASKS + "/" + task_id, params=QUERY_PARAMS, headers=HEADERS)
            response.raise_for_status()
        except requests.exceptions.HTTPError as errh:
            _LOGGER.error(errh.args[0], extra={"function": inspect.currentframe().f_code.co_name})
            raise
        except requests.exceptions.ReadTimeout:
            _LOGGER.error("Time out", extra={"function": inspect.currentframe().f_code.co_name})
            raise
        except requests.exceptions.ConnectionError:
            _LOGGER.error("Connection error", extra={"function": inspect.currentframe().f_code.co_name})
            raise
        except requests.exceptions.RequestException:
            _LOGGER.error("Exception request", extra={"function": inspect.currentframe().f_code.co_name})
            raise

        task_result = response.json()
        if task_result.get("status") == "succeeded":
            sandbox_analysis_results = task_result.get("resourceLocation")
        if task_result.get("status") == "failed":
            sandbox_analysis_failed = True
        _LOGGER.info("Sandbox Analysis running", extra={"function": inspect.currentframe().f_code.co_name})
        sleep(10)

    if sandbox_analysis_failed:
        _LOGGER.error("Sandbox Analysis failed", extra={"function": inspect.currentframe().f_code.co_name})

    return sandbox_analysis_results


def sandbox_get_analysis_results(sandbox_analysis_results):
    try:
        response = requests.get(sandbox_analysis_results, params=QUERY_PARAMS, headers=HEADERS)
        response.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        _LOGGER.error(errh.args[0], extra={"function": inspect.currentframe().f_code.co_name})
        raise
    except requests.exceptions.ReadTimeout:
        _LOGGER.error("Time out", extra={"function": inspect.currentframe().f_code.co_name})
        raise
    except requests.exceptions.ConnectionError:
        _LOGGER.error("Connection error", extra={"function": inspect.currentframe().f_code.co_name})
        raise
    except requests.exceptions.RequestException:
        _LOGGER.error("Exception request", extra={"function": inspect.currentframe().f_code.co_name})
        raise

    analysis_result = response.json()

    detection_names = " ".join(analysis_result.get("detectionNames", ["n/a"]))
    threat_types = " ".join(analysis_result.get("threatTypes", ["n/a"]))
    scan_date = datetime.strftime(
        datetime.fromisoformat(analysis_result.get("analysisCompletionDateTime")), "%m/%d/%Y %H:%M:%S"
    )
    tags = [
        f"{SB_TAG_PREFIX}risk-level={analysis_result.get('riskLevel', 'n/a')}",
        f"{SB_TAG_PREFIX}detection-names={detection_names}",
        f"{SB_TAG_PREFIX}threat-type={threat_types}",
        f"{SB_TAG_PREFIX}analysis-completed={scan_date}",
    ]

    return tags


# #############################################################################
# Lambda Handler
# #############################################################################
def lambda_handler(event, context):

    # create v1fs connection handle
    # handle = amaas.grpc.init(v1_amaas_server, V1_API_KEY, True)
    # or use v1 regions
    handle = amaas.grpc.init_by_region(V1_REGION, V1_API_KEY, True)

    for record in event["Records"]:

        bucket = record["s3"]["bucket"]["name"]
        key = urllib.parse.unquote_plus(record["s3"]["object"]["key"], encoding="utf-8")
        tags_fs = []
        tags_sb = []

        try:
            s3object = s3.Object(bucket, key)

            # Load file into a buffer
            buffer = s3object.get().get("Body").read()

            _LOGGER.info(f"executing scan on {key}.", extra={"function": inspect.currentframe().f_code.co_name})

            s = time.perf_counter()

            # Scan the file using File Security
            if V1_FSS:
                tags_fs = fss_submit(handle, key, buffer)

            # Scan the file using the Sandbox
            if V1_SANDBOX:
                task_id = sandbox_submit(key, buffer)
                sandbox_analysis_results = sandbox_wait_for_result(task_id)
                tags_sb = sandbox_get_analysis_results(sandbox_analysis_results)

            elapsed = time.perf_counter() - s

            # tags = tags_fs.extend(tags_sb)

            existing_tags = s3_client.get_object_tagging(Bucket=bucket, Key=key)

            # Merge existing tags with new ones
            merged_tags = existing_tags.get("TagSet") + tags_fs + tags_sb  # tags

            # Remove duplicates (if needed)
            merged_tags = list(set(merged_tags))

            # Convert to TagSet format
            key_value_dict = [{"Key": item.split("=")[0], "Value": item.split("=")[1]} for item in merged_tags]

            s3_client.put_object_tagging(Bucket=bucket, Key=key, Tagging={"TagSet": key_value_dict})

            _LOGGER.info(
                f"Scan executed in {elapsed:0.2f} seconds.", extra={"function": inspect.currentframe().f_code.co_name}
            )
            _LOGGER.info(f"Tags -> {str(merged_tags)}", extra={"function": inspect.currentframe().f_code.co_name})

        except Exception as e:
            _LOGGER.error(e, extra={"function": inspect.currentframe().f_code.co_name})
            _LOGGER.error(
                "Error scan Object {} from Bucket {}.".format(key, bucket),
                extra={"function": inspect.currentframe().f_code.co_name},
            )

    amaas.grpc.quit(handle)
