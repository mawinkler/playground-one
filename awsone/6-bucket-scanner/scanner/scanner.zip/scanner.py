import json
import os
import time
import urllib.parse
from datetime import datetime

import amaas.grpc
import boto3

v1_region = os.getenv("V1_REGION")
v1_api_key = os.getenv("V1_API_KEY")

s3 = boto3.resource("s3")
s3_client = boto3.client("s3")


FSS_TAG_PREFIX = "fss-"


def lambda_handler(event, context):

    # create v1fs connection handle
    # handle = amaas.grpc.init(v1_amaas_server, v1_api_key, True)
    # or use v1 regions
    handle = amaas.grpc.init_by_region(v1_region, v1_api_key, True)

    for record in event["Records"]:

        bucket = record["s3"]["bucket"]["name"]
        key = urllib.parse.unquote_plus(record["s3"]["object"]["key"], encoding="utf-8")

        pml = True
        feedback = True
        verbose = True
        digest = True

        try:
            s3object = s3.Object(bucket, key)
            # Load file into a buffer
            buffer = s3object.get().get("Body").read()

            print(f"executing scan on {key}.")

            s = time.perf_counter()

            # Scan the file
            scan_resp = amaas.grpc.scan_buffer(
                handle,
                buffer,
                key,
                tags=["pgo"],
                pml=pml,
                feedback=feedback,
                verbose=verbose,
                digest=digest,
            )

            response = json.loads(scan_resp)

            scanning_result = response.get("result")
            findings = scanning_result.get("atse").get("malwareCount")
            scan_result = "malicious" if findings else "no issues found"
            scan_date = datetime.strftime(
                datetime.fromisoformat(response.get("timestamp").get("end")), "%m/%d/%Y %H:%M:%S"
            )
            malware_name = scanning_result.get("atse").get("malware")[0].get("name") if findings else "n/a"

            tags = [
                f"{FSS_TAG_PREFIX}scanned=true",
                f"{FSS_TAG_PREFIX}scan-date={scan_date}",
                f"{FSS_TAG_PREFIX}scan-result={scan_result}",
                f"{FSS_TAG_PREFIX}scan-detail-code={malware_name}",
            ]

            elapsed = time.perf_counter() - s

            existing_tags = s3_client.get_object_tagging(Bucket=bucket, Key=key)

            # Merge existing tags with new ones
            merged_tags = existing_tags.get("TagSet") + tags

            # Remove duplicates (if needed)
            merged_tags = list(set(merged_tags))

            # Convert to TagSet format
            key_value_dict = [{"Key": item.split("=")[0], "Value": item.split("=")[1]} for item in merged_tags]

            s3_client.put_object_tagging(Bucket=bucket, Key=key, Tagging={"TagSet": key_value_dict})

            print(f"scan executed in {elapsed:0.2f} seconds.")
            print(f"scan result -> {str(scan_result)}")
            print(f"tags -> {str(merged_tags)}")

        except Exception as e:
            print(e)
            print("error scan object {} from bucket {}.".format(key, bucket))

    amaas.grpc.quit(handle)
